﻿跳一跳作弊器Pascal版
=============
* http://axpokl.com/tiaoyitiao.zip
* https://github.com/axpokl/tiaoyitiao
-------------
* 1，安装adb软件
* 2，设定adb环境变量
* 3，连接Android手机
* 4，打开Android手机USB调试
* 5，修改tiaoyitiao.ini配置文件
* 6，运行tiaoyitiao.exe主程序
